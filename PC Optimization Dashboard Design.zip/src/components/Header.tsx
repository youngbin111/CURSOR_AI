import { motion } from 'motion/react';
import { 
  Bell, 
  Search, 
  User, 
  Settings,
  Power,
  Shield,
  ChevronDown
} from 'lucide-react';
import { useState } from 'react';

export function Header() {
  const [notifications] = useState(3);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  return (
    <motion.header
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      className="h-16 glass-panel neon-glow-blue flex items-center justify-between px-6 mb-6"
    >
      {/* Left Section */}
      <div className="flex items-center space-x-4">
        <motion.div
          animate={{ rotate: [0, 360] }}
          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          className="w-8 h-8 rounded-full bg-gradient-to-r from-[#00d4ff] to-[#00ff88] flex items-center justify-center"
        >
          <Shield size={16} className="text-black" />
        </motion.div>
        
        <div>
          <h1 className="text-lg font-bold gradient-text">PC 닥터 🤖</h1>
          <p className="text-xs text-gray-400">AI 건강 지키미 가동 중</p>
        </div>
      </div>

      {/* Center Section - Search */}
      <div className="flex-1 max-w-md mx-8">
        <div className="relative">
          <Search size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="뭐 찾고 있어요? 🔍"
            className="w-full pl-10 pr-4 py-2 bg-white/10 border border-white/20 rounded-lg 
                     text-white placeholder-gray-400 focus:outline-none focus:ring-2 
                     focus:ring-[#00d4ff] focus:border-transparent backdrop-blur-sm
                     transition-all duration-300"
          />
        </div>
      </div>

      {/* Right Section */}
      <div className="flex items-center space-x-4">
        {/* System Status */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.5, duration: 0.5 }}
          className="flex items-center space-x-2 px-3 py-1 bg-[#00ff88]/20 rounded-full"
        >
          <div className="w-2 h-2 bg-[#00ff88] rounded-full pulse-glow" />
          <span className="text-xs text-[#00ff88] font-medium">컨디션 굿! 👍</span>
        </motion.div>

        {/* Notifications */}
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
          className="relative p-2 rounded-lg bg-white/10 hover:bg-white/20 
                   transition-colors duration-200 neon-glow-blue"
        >
          <Bell size={18} className="text-[#00d4ff]" />
          {notifications > 0 && (
            <motion.span
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="absolute -top-1 -right-1 w-5 h-5 bg-[#ff2d5a] rounded-full 
                       text-xs text-white flex items-center justify-center font-bold
                       pulse-glow"
            >
              {notifications}
            </motion.span>
          )}
        </motion.button>

        {/* User Menu */}
        <div className="relative">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
            className="flex items-center space-x-2 p-2 rounded-lg bg-white/10 
                     hover:bg-white/20 transition-colors duration-200"
          >
            <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[#a855f7] to-[#00d4ff] 
                          flex items-center justify-center">
              <User size={16} className="text-white" />
            </div>
            <ChevronDown size={14} className="text-gray-400" />
          </motion.button>

          {/* Dropdown Menu */}
          {isUserMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.95 }}
              className="absolute right-0 mt-2 w-48 glass-panel neon-glow-purple 
                       py-2 z-50"
            >
              <button className="w-full px-4 py-2 text-left text-sm text-gray-300 
                               hover:bg-white/10 transition-colors duration-200
                               flex items-center space-x-2">
                <User size={14} />
                <span>프로필</span>
              </button>
              <button className="w-full px-4 py-2 text-left text-sm text-gray-300 
                               hover:bg-white/10 transition-colors duration-200
                               flex items-center space-x-2">
                <Settings size={14} />
                <span>설정</span>
              </button>
              <hr className="my-2 border-white/20" />
              <button className="w-full px-4 py-2 text-left text-sm text-[#ff2d5a] 
                               hover:bg-white/10 transition-colors duration-200
                               flex items-center space-x-2">
                <Power size={14} />
                <span>로그아웃</span>
              </button>
            </motion.div>
          )}
        </div>
      </div>
    </motion.header>
  );
}