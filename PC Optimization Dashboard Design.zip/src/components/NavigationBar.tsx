import { motion } from 'motion/react';
import { 
  Monitor, 
  HardDrive, 
  Cpu, 
  Activity, 
  Settings, 
  Shield,
  Gauge,
  Zap,
  Heart
} from 'lucide-react';
import { useState } from 'react';

interface NavItem {
  id: string;
  icon: React.ComponentType<any>;
  label: string;
  color: 'blue' | 'green' | 'purple';
}

const navItems: NavItem[] = [
  { id: 'beginner', icon: Heart, label: '쉬운 건강체크', color: 'green' },
  { id: 'dashboard', icon: Gauge, label: '컨디션 체크', color: 'blue' },
  { id: 'system', icon: Monitor, label: '건강 진단', color: 'green' },
  { id: 'performance', icon: Activity, label: '속도 테스트', color: 'purple' },
  { id: 'storage', icon: HardDrive, label: '짐 정리', color: 'blue' },
  { id: 'processes', icon: Cpu, label: '일꾼 관리', color: 'green' },
  { id: 'optimization', icon: Zap, label: '터보 모드', color: 'purple' },
  { id: 'security', icon: Shield, label: '방패막이', color: 'blue' },
  { id: 'settings', icon: Settings, label: '설정', color: 'green' }
];

interface NavigationBarProps {
  activeTab: string;
  onTabChange: (tabId: string) => void;
}

export function NavigationBar({ activeTab, onTabChange }: NavigationBarProps) {
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);

  const getColorClasses = (color: 'blue' | 'green' | 'purple', isActive: boolean, isHovered: boolean) => {
    const colors = {
      blue: {
        text: isActive ? 'text-[#00d4ff]' : 'text-gray-400',
        glow: isActive || isHovered ? 'neon-glow-blue' : '',
        bg: isActive ? 'bg-[#00d4ff]/20' : isHovered ? 'bg-[#00d4ff]/10' : ''
      },
      green: {
        text: isActive ? 'text-[#00ff88]' : 'text-gray-400',
        glow: isActive || isHovered ? 'neon-glow-green' : '',
        bg: isActive ? 'bg-[#00ff88]/20' : isHovered ? 'bg-[#00ff88]/10' : ''
      },
      purple: {
        text: isActive ? 'text-[#a855f7]' : 'text-gray-400',
        glow: isActive || isHovered ? 'neon-glow-purple' : '',
        bg: isActive ? 'bg-[#a855f7]/20' : isHovered ? 'bg-[#a855f7]/10' : ''
      }
    };
    return colors[color];
  };

  return (
    <motion.div
      initial={{ x: -100, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      className="w-64 h-full glass-panel neon-glow-blue p-6"
    >
      <div className="mb-8">
        <h2 className="text-xl font-bold gradient-text mb-2">PC 닥터 🤖</h2>
        <p className="text-xs text-gray-400">AI 건강 지키미</p>
      </div>

      <nav className="space-y-2">
        {navItems.map((item, index) => {
          const isActive = activeTab === item.id;
          const isHovered = hoveredItem === item.id;
          const colorClasses = getColorClasses(item.color, isActive, isHovered);
          const Icon = item.icon;

          return (
            <motion.button
              key={item.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
              onClick={() => onTabChange(item.id)}
              onMouseEnter={() => setHoveredItem(item.id)}
              onMouseLeave={() => setHoveredItem(null)}
              className={`
                w-full flex items-center space-x-3 px-4 py-3 rounded-lg
                transition-all duration-300 ease-out
                hover:scale-105 hover:translate-x-2
                ${colorClasses.text} ${colorClasses.bg} ${colorClasses.glow}
                border border-transparent hover:border-white/20
              `}
            >
              <motion.div
                animate={{ 
                  rotate: isHovered ? 360 : 0,
                  scale: isActive ? 1.2 : 1
                }}
                transition={{ duration: 0.3 }}
              >
                <Icon size={20} />
              </motion.div>
              
              <span className="text-sm font-medium">{item.label}</span>
              
              {isActive && (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="w-2 h-2 rounded-full bg-current ml-auto pulse-glow"
                />
              )}
            </motion.button>
          );
        })}
      </nav>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 0.5 }}
        className="mt-8 p-4 glass-panel"
      >
        <div className="text-xs text-gray-400 mb-2">바이탈 사인 ⚡</div>
        <div className="space-y-2">
          <div className="flex justify-between text-xs">
            <span className="text-gray-300">체온</span>
            <span className="text-[#00ff88]">42°C 😎</span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-gray-300">심박수</span>
            <span className="text-[#00d4ff]">1200 BPM</span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-gray-300">에너지</span>
            <span className="text-[#a855f7]">65W ⚡</span>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}