import { motion } from 'motion/react';
import { useState, useEffect } from 'react';
import { GlassPanel } from './GlassPanel';
import { CircularGauge } from './CircularGauge';
import { 
  Trash2, 
  FolderOpen, 
  FileText, 
  Image, 
  Video, 
  Music,
  Download,
  Archive,
  AlertTriangle,
  CheckCircle,
  Play,
  RotateCcw
} from 'lucide-react';
import { Button } from './ui/button';
import { Progress } from './ui/progress';

interface FileCategory {
  id: string;
  name: string;
  icon: React.ComponentType<any>;
  size: number;
  count: number;
  color: 'blue' | 'green' | 'purple';
  selected: boolean;
}

export function DiskCleanup() {
  const [isScanning, setIsScanning] = useState(false);
  const [isCleaning, setIsCleaning] = useState(false);
  const [cleanupProgress, setCleanupProgress] = useState(0);
  const [totalDiskSpace] = useState(512); // GB
  const [usedSpace, setUsedSpace] = useState(387);
  const [categories, setCategories] = useState<FileCategory[]>([
    { id: 'temp', name: '임시 파일', icon: FileText, size: 2.4, count: 1247, color: 'blue', selected: true },
    { id: 'cache', name: '캐시 파일', icon: Archive, size: 1.8, count: 895, color: 'green', selected: true },
    { id: 'downloads', name: '다운로드', icon: Download, size: 15.2, count: 156, color: 'purple', selected: false },
    { id: 'images', name: '중복 이미지', icon: Image, size: 3.7, count: 284, color: 'blue', selected: true },
    { id: 'videos', name: '대용량 비디오', icon: Video, size: 8.9, count: 23, color: 'green', selected: false },
    { id: 'music', name: '음악 파일', icon: Music, size: 4.3, count: 567, color: 'purple', selected: false },
  ]);

  const scanDisk = async () => {
    setIsScanning(true);
    // 스캔 시뮬레이션
    await new Promise(resolve => setTimeout(resolve, 3000));
    setIsScanning(false);
  };

  const startCleanup = async () => {
    setIsCleaning(true);
    setCleanupProgress(0);
    
    // 정리 진행률 시뮬레이션
    for (let i = 0; i <= 100; i += 10) {
      setCleanupProgress(i);
      await new Promise(resolve => setTimeout(resolve, 200));
    }
    
    // 선택된 카테고리의 공간 해제
    const freedSpace = categories
      .filter(cat => cat.selected)
      .reduce((total, cat) => total + cat.size, 0);
    
    setUsedSpace(prev => Math.max(0, prev - freedSpace));
    
    // 카테고리 초기화
    setCategories(prev => prev.map(cat => ({
      ...cat,
      size: cat.selected ? 0 : cat.size,
      count: cat.selected ? 0 : cat.count,
      selected: false
    })));
    
    setIsCleaning(false);
    setCleanupProgress(0);
  };

  const toggleCategory = (id: string) => {
    setCategories(prev => prev.map(cat => 
      cat.id === id ? { ...cat, selected: !cat.selected } : cat
    ));
  };

  const getTotalSize = () => categories.filter(cat => cat.selected).reduce((total, cat) => total + cat.size, 0);

  const getColorClass = (color: 'blue' | 'green' | 'purple') => {
    const colors = {
      blue: 'text-[#00d4ff]',
      green: 'text-[#00ff88]',
      purple: 'text-[#a855f7]'
    };
    return colors[color];
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <GlassPanel delay={0.1} glow="blue" className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold gradient-text mb-2">📦 짐 정리</h2>
            <p className="text-gray-400">필요 없는 짐들을 버려서 공간을 만들어볼까요?</p>
          </div>
          <motion.div
            animate={{ rotate: isScanning ? 360 : 0 }}
            transition={{ duration: 2, repeat: isScanning ? Infinity : 0, ease: "linear" }}
          >
            <Trash2 size={32} className="text-[#00d4ff]" />
          </motion.div>
        </div>
      </GlassPanel>

      {/* Disk Usage Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <GlassPanel delay={0.2} glow="green" className="lg:col-span-1 p-6">
          <h3 className="text-lg font-bold text-[#00ff88] mb-4">💾 창고 현황</h3>
          <div className="flex justify-center">
            <CircularGauge
              value={usedSpace}
              max={totalDiskSpace}
              label="💾 창고 점유율"
              color="green"
              size={160}
              emoji="💾"
              subtitle="짐이 많네요!"
            />
          </div>
          <div className="mt-4 space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-400">전체 용량</span>
              <span className="text-white">{totalDiskSpace} GB</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">사용 중</span>
              <span className="text-[#00ff88]">{usedSpace.toFixed(1)} GB</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">사용 가능</span>
              <span className="text-[#00d4ff]">{(totalDiskSpace - usedSpace).toFixed(1)} GB</span>
            </div>
          </div>
        </GlassPanel>

        {/* Cleanup Categories */}
        <GlassPanel delay={0.3} glow="purple" className="lg:col-span-2 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold text-[#a855f7]">정리 가능한 파일</h3>
            <Button
              onClick={scanDisk}
              disabled={isScanning || isCleaning}
              className="bg-[#00d4ff]/20 hover:bg-[#00d4ff]/30 text-[#00d4ff] border border-[#00d4ff]/30"
            >
              {isScanning ? (
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                >
                  <RotateCcw size={16} />
                </motion.div>
              ) : (
                <FolderOpen size={16} />
              )}
              <span className="ml-2">{isScanning ? '스캔 중...' : '다시 스캔'}</span>
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {categories.map((category, index) => {
              const Icon = category.icon;
              return (
                <motion.div
                  key={category.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + index * 0.1, duration: 0.3 }}
                  onClick={() => toggleCategory(category.id)}
                  className={`
                    p-4 rounded-lg cursor-pointer transition-all duration-300
                    border ${category.selected 
                      ? 'bg-white/10 border-white/30' 
                      : 'bg-white/5 border-white/10 hover:bg-white/10'
                    }
                  `}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <Icon size={20} className={getColorClass(category.color)} />
                      <span className="text-sm font-medium text-white">{category.name}</span>
                    </div>
                    {category.selected && (
                      <CheckCircle size={16} className="text-[#00ff88]" />
                    )}
                  </div>
                  <div className="text-xs text-gray-400">
                    {category.size.toFixed(1)} GB • {category.count.toLocaleString()} 파일
                  </div>
                </motion.div>
              );
            })}
          </div>
        </GlassPanel>
      </div>

      {/* Cleanup Controls */}
      <GlassPanel delay={0.5} className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-bold text-white">정리 실행</h3>
            <p className="text-sm text-gray-400">
              선택된 항목: {categories.filter(cat => cat.selected).length}개 • 
              확보 예상 용량: {getTotalSize().toFixed(1)} GB
            </p>
          </div>
          
          <Button
            onClick={startCleanup}
            disabled={isCleaning || getTotalSize() === 0}
            className="bg-gradient-to-r from-[#00d4ff] to-[#00ff88] hover:from-[#00d4ff]/80 hover:to-[#00ff88]/80 text-black font-bold"
          >
            {isCleaning ? (
              <>
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                >
                  <RotateCcw size={16} />
                </motion.div>
                <span className="ml-2">정리 중...</span>
              </>
            ) : (
              <>
                <Play size={16} />
                <span className="ml-2">정리 시작</span>
              </>
            )}
          </Button>
        </div>

        {isCleaning && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="mt-4"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-300">정리 진행률</span>
              <span className="text-sm text-[#00d4ff]">{cleanupProgress}%</span>
            </div>
            <Progress 
              value={cleanupProgress} 
              className="h-2 bg-white/10"
            />
          </motion.div>
        )}
      </GlassPanel>

      {/* Cleanup History */}
      <GlassPanel delay={0.6} className="p-6">
        <h3 className="text-lg font-bold text-white mb-4">최근 정리 기록</h3>
        <div className="space-y-3">
          {[
            { date: '2024-01-15', freed: '3.2 GB', files: 1584 },
            { date: '2024-01-10', freed: '1.8 GB', files: 892 },
            { date: '2024-01-05', freed: '4.1 GB', files: 2156 },
          ].map((record, index) => (
            <motion.div
              key={record.date}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.7 + index * 0.1, duration: 0.3 }}
              className="flex items-center justify-between p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
            >
              <div className="flex items-center space-x-3">
                <CheckCircle size={16} className="text-[#00ff88]" />
                <span className="text-sm text-gray-300">{record.date}</span>
              </div>
              <div className="text-right text-xs">
                <div className="text-[#00d4ff]">{record.freed} 확보</div>
                <div className="text-gray-400">{record.files.toLocaleString()} 파일</div>
              </div>
            </motion.div>
          ))}
        </div>
      </GlassPanel>
    </div>
  );
}