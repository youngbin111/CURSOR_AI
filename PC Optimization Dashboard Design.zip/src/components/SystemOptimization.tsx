import { motion } from 'motion/react';
import { useState, useEffect } from 'react';
import { GlassPanel } from './GlassPanel';
import { 
  Zap, 
  Cpu, 
  MemoryStick, 
  HardDrive,
  Wifi,
  Shield,
  Settings,
  TrendingUp,
  CheckCircle,
  AlertTriangle,
  Play,
  Pause,
  RotateCcw,
  Rocket,
  Target,
  Activity
} from 'lucide-react';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Switch } from './ui/switch';

interface OptimizationTask {
  id: string;
  name: string;
  description: string;
  icon: React.ComponentType<any>;
  impact: 'high' | 'medium' | 'low';
  category: 'performance' | 'memory' | 'network' | 'security';
  enabled: boolean;
  status: 'pending' | 'running' | 'completed' | 'error';
  progress: number;
  estimatedTime: number; // seconds
}

interface PerformanceMetric {
  name: string;
  before: number;
  after: number;
  unit: string;
  color: 'blue' | 'green' | 'purple';
}

export function SystemOptimization() {
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [currentTask, setCurrentTask] = useState<string | null>(null);
  const [overallProgress, setOverallProgress] = useState(0);
  const [optimizationComplete, setOptimizationComplete] = useState(false);
  
  const [tasks, setTasks] = useState<OptimizationTask[]>([
    {
      id: 'cpu-boost',
      name: '🧠 두뇌 활성화',
      description: 'CPU야, 더 열심히 일해줘!',
      icon: Cpu,
      impact: 'high',
      category: 'performance',
      enabled: true,
      status: 'pending',
      progress: 0,
      estimatedTime: 15
    },
    {
      id: 'memory-optimization',
      name: '⚡ 기억력 향상',
      description: '잊어버린 기억들을 정리해드릴게요',
      icon: MemoryStick,
      impact: 'high',
      category: 'memory',
      enabled: true,
      status: 'pending',
      progress: 0,
      estimatedTime: 20
    },
    {
      id: 'disk-defrag',
      name: '📦 창고 정리',
      description: '흩어진 파일들을 깔끔하게 정리',
      icon: HardDrive,
      impact: 'medium',
      category: 'performance',
      enabled: true,
      status: 'pending',
      progress: 0,
      estimatedTime: 30
    },
    {
      id: 'network-optimization',
      name: '🌐 인터넷 가속',
      description: '인터넷을 더 빠르게 만들어드려요',
      icon: Wifi,
      impact: 'medium',
      category: 'network',
      enabled: false,
      status: 'pending',
      progress: 0,
      estimatedTime: 10
    },
    {
      id: 'startup-optimization',
      name: '🚀 빠른 시작',
      description: '부팅을 번개처럼 빠르게!',
      icon: Rocket,
      impact: 'high',
      category: 'performance',
      enabled: true,
      status: 'pending',
      progress: 0,
      estimatedTime: 12
    },
    {
      id: 'security-scan',
      name: '🛡️ 방패 강화',
      description: '나쁜 놈들로부터 PC를 보호해요',
      icon: Shield,
      impact: 'medium',
      category: 'security',
      enabled: false,
      status: 'pending',
      progress: 0,
      estimatedTime: 25
    }
  ]);

  const [performanceMetrics, setPerformanceMetrics] = useState<PerformanceMetric[]>([
    { name: '부팅 시간', before: 45, after: 28, unit: '초', color: 'blue' },
    { name: '메모리 사용률', before: 78, after: 52, unit: '%', color: 'green' },
    { name: '응답 시간', before: 850, after: 420, unit: 'ms', color: 'purple' },
    { name: 'CPU 효율성', before: 65, after: 89, unit: '%', color: 'blue' },
  ]);

  const getImpactColor = (impact: 'high' | 'medium' | 'low') => {
    const colors = {
      high: 'text-[#00ff88]',
      medium: 'text-[#00d4ff]',
      low: 'text-[#a855f7]'
    };
    return colors[impact];
  };

  const getCategoryIcon = (category: string) => {
    const icons = {
      performance: TrendingUp,
      memory: MemoryStick,
      network: Wifi,
      security: Shield
    };
    return icons[category as keyof typeof icons] || Settings;
  };

  const toggleTask = (taskId: string) => {
    setTasks(prev => prev.map(task => 
      task.id === taskId ? { ...task, enabled: !task.enabled } : task
    ));
  };

  const startOptimization = async () => {
    const enabledTasks = tasks.filter(task => task.enabled);
    if (enabledTasks.length === 0) return;

    setIsOptimizing(true);
    setOptimizationComplete(false);
    setOverallProgress(0);

    for (let i = 0; i < enabledTasks.length; i++) {
      const task = enabledTasks[i];
      setCurrentTask(task.id);
      
      // 태스크 상태를 'running'으로 변경
      setTasks(prev => prev.map(t => 
        t.id === task.id ? { ...t, status: 'running' } : t
      ));

      // 태스크 진행률 시뮬레이션
      for (let progress = 0; progress <= 100; progress += 5) {
        setTasks(prev => prev.map(t => 
          t.id === task.id ? { ...t, progress } : t
        ));
        await new Promise(resolve => setTimeout(resolve, task.estimatedTime * 10));
      }

      // 태스크 완료
      setTasks(prev => prev.map(t => 
        t.id === task.id ? { ...t, status: 'completed', progress: 100 } : t
      ));

      // 전체 진행률 업데이트
      setOverallProgress(((i + 1) / enabledTasks.length) * 100);
    }

    setCurrentTask(null);
    setIsOptimizing(false);
    setOptimizationComplete(true);
  };

  const resetOptimization = () => {
    setTasks(prev => prev.map(task => ({
      ...task,
      status: 'pending',
      progress: 0
    })));
    setOverallProgress(0);
    setOptimizationComplete(false);
    setCurrentTask(null);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'running':
        return (
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          >
            <RotateCcw size={16} className="text-[#00d4ff]" />
          </motion.div>
        );
      case 'completed':
        return <CheckCircle size={16} className="text-[#00ff88]" />;
      case 'error':
        return <AlertTriangle size={16} className="text-[#ff2d5a]" />;
      default:
        return <Target size={16} className="text-gray-400" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <GlassPanel delay={0.1} glow="purple" className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold gradient-text mb-2">⚡ 터보 모드</h2>
            <p className="text-gray-400">AI가 PC를 빠르게 만들어드릴게요! 🚀</p>
          </div>
          <motion.div
            animate={{ 
              scale: isOptimizing ? [1, 1.2, 1] : 1,
              rotate: isOptimizing ? 360 : 0 
            }}
            transition={{ 
              scale: { duration: 1, repeat: isOptimizing ? Infinity : 0 },
              rotate: { duration: 2, repeat: isOptimizing ? Infinity : 0, ease: "linear" }
            }}
          >
            <Zap size={32} className="text-[#a855f7]" />
          </motion.div>
        </div>
      </GlassPanel>

      {/* Optimization Tasks */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <GlassPanel delay={0.2} glow="blue" className="p-6">
          <h3 className="text-lg font-bold text-[#00d4ff] mb-4">🔧 할 일 목록</h3>
          <div className="space-y-4">
            {tasks.map((task, index) => {
              const Icon = task.icon;
              const CategoryIcon = getCategoryIcon(task.category);
              
              return (
                <motion.div
                  key={task.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + index * 0.1, duration: 0.3 }}
                  className={`
                    p-4 rounded-lg border transition-all duration-300
                    ${task.enabled 
                      ? 'bg-white/10 border-white/30' 
                      : 'bg-white/5 border-white/10'
                    }
                  `}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-3">
                      <Icon size={20} className={getImpactColor(task.impact)} />
                      <div>
                        <div className="text-sm font-medium text-white">{task.name}</div>
                        <div className="text-xs text-gray-400 flex items-center space-x-1">
                          <CategoryIcon size={12} />
                          <span>영향도: {task.impact}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(task.status)}
                      <Switch
                        checked={task.enabled}
                        onCheckedChange={() => toggleTask(task.id)}
                        disabled={isOptimizing}
                      />
                    </div>
                  </div>
                  
                  <p className="text-xs text-gray-400 mb-2">{task.description}</p>
                  
                  {task.status === 'running' && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="mt-2"
                    >
                      <Progress value={task.progress} className="h-1 bg-white/10" />
                    </motion.div>
                  )}
                </motion.div>
              );
            })}
          </div>
        </GlassPanel>

        {/* Control Panel */}
        <GlassPanel delay={0.3} glow="green" className="p-6">
          <h3 className="text-lg font-bold text-[#00ff88] mb-4">제어판</h3>
          
          <div className="space-y-4">
            <div className="text-sm text-gray-300">
              <div className="flex justify-between mb-2">
                <span>선택된 작업:</span>
                <span className="text-[#00d4ff]">{tasks.filter(t => t.enabled).length}개</span>
              </div>
              <div className="flex justify-between mb-2">
                <span>예상 소요 시간:</span>
                <span className="text-[#00ff88]">
                  {Math.round(tasks.filter(t => t.enabled).reduce((sum, t) => sum + t.estimatedTime, 0) / 60)}분
                </span>
              </div>
              <div className="flex justify-between">
                <span>현재 상태:</span>
                <span className={`${isOptimizing ? 'text-[#00d4ff]' : optimizationComplete ? 'text-[#00ff88]' : 'text-gray-400'}`}>
                  {isOptimizing ? '최적화 중' : optimizationComplete ? '완료' : '대기 중'}
                </span>
              </div>
            </div>

            {isOptimizing && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-2"
              >
                <div className="flex justify-between text-sm">
                  <span className="text-gray-300">전체 진행률</span>
                  <span className="text-[#00d4ff]">{Math.round(overallProgress)}%</span>
                </div>
                <Progress value={overallProgress} className="h-2 bg-white/10" />
                {currentTask && (
                  <div className="text-xs text-gray-400">
                    현재: {tasks.find(t => t.id === currentTask)?.name}
                  </div>
                )}
              </motion.div>
            )}

            <div className="flex space-x-2 pt-4">
              <Button
                onClick={startOptimization}
                disabled={isOptimizing || tasks.filter(t => t.enabled).length === 0}
                className="flex-1 bg-gradient-to-r from-[#00d4ff] to-[#00ff88] hover:from-[#00d4ff]/80 hover:to-[#00ff88]/80 text-black font-bold"
              >
                {isOptimizing ? (
                  <>
                    <Pause size={16} />
                    <span className="ml-2">최적화 중...</span>
                  </>
                ) : (
                  <>
                    <Play size={16} />
                    <span className="ml-2">최적화 시작</span>
                  </>
                )}
              </Button>
              
              <Button
                onClick={resetOptimization}
                disabled={isOptimizing}
                variant="outline"
                className="border-white/30 text-white hover:bg-white/10"
              >
                <RotateCcw size={16} />
              </Button>
            </div>
          </div>
        </GlassPanel>
      </div>

      {/* Performance Metrics */}
      {optimizationComplete && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <GlassPanel glow="purple" className="p-6">
            <h3 className="text-lg font-bold text-[#a855f7] mb-4">성능 개선 결과</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {performanceMetrics.map((metric, index) => (
                <motion.div
                  key={metric.name}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1, duration: 0.3 }}
                  className="text-center p-4 rounded-lg bg-white/5"
                >
                  <div className="text-sm text-gray-400 mb-2">{metric.name}</div>
                  <div className="space-y-1">
                    <div className="text-xs text-gray-500">
                      이전: {metric.before}{metric.unit}
                    </div>
                    <div className={`text-lg font-bold ${
                      metric.color === 'blue' ? 'text-[#00d4ff]' :
                      metric.color === 'green' ? 'text-[#00ff88]' :
                      'text-[#a855f7]'
                    }`}>
                      {metric.after}{metric.unit}
                    </div>
                    <div className="text-xs text-[#00ff88]">
                      {metric.name === '메모리 사용률' || metric.name === '응답 시간' 
                        ? `-${Math.round(((metric.before - metric.after) / metric.before) * 100)}%`
                        : `+${Math.round(((metric.after - metric.before) / metric.before) * 100)}%`
                      }
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </GlassPanel>
        </motion.div>
      )}

      {/* Recommendations */}
      <GlassPanel delay={0.4} className="p-6">
        <h3 className="text-lg font-bold text-white mb-4">AI 추천 사항</h3>
        <div className="space-y-3">
          {[
            { 
              text: '주간 자동 최적화 스케줄을 설정하여 지속적인 성능 유지를 권장합니다.',
              priority: 'high',
              icon: Target
            },
            { 
              text: 'SSD 상태를 정기적으로 점검하여 수명을 연장하세요.',
              priority: 'medium',
              icon: HardDrive
            },
            { 
              text: '사용하지 않는 시작 프로그램을 비활성화하여 부팅 시간을 단축하세요.',
              priority: 'high',
              icon: Rocket
            }
          ].map((recommendation, index) => {
            const Icon = recommendation.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 + index * 0.1, duration: 0.3 }}
                className="flex items-start space-x-3 p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
              >
                <Icon size={16} className={`mt-1 ${
                  recommendation.priority === 'high' ? 'text-[#00ff88]' : 'text-[#00d4ff]'
                }`} />
                <div className="flex-1">
                  <p className="text-sm text-gray-300">{recommendation.text}</p>
                </div>
                <div className={`text-xs px-2 py-1 rounded ${
                  recommendation.priority === 'high' 
                    ? 'bg-[#00ff88]/20 text-[#00ff88]' 
                    : 'bg-[#00d4ff]/20 text-[#00d4ff]'
                }`}>
                  {recommendation.priority === 'high' ? '높음' : '보통'}
                </div>
              </motion.div>
            );
          })}
        </div>
      </GlassPanel>
    </div>
  );
}