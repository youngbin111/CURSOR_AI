import { motion } from 'motion/react';
import { useState, useEffect } from 'react';
import { GlassPanel } from './GlassPanel';
import { CircularGauge } from './CircularGauge';
import { 
  Brain, 
  BookOpen, 
  FolderOpen, 
  Heart,
  Trash2,
  HelpCircle,
  AlertTriangle,
  CheckCircle,
  TrendingUp,
  Zap
} from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

interface PerformanceCard {
  id: string;
  friendlyName: string;
  techName: string;
  icon: React.ComponentType<any>;
  emoji: string;
  value: number;
  max: number;
  color: 'blue' | 'green' | 'purple';
  status: 'good' | 'warning' | 'critical';
  tooltip: string;
  recommendation?: string;
}

export function BeginnerFriendlyDashboard() {
  const [cpuUsage, setCpuUsage] = useState(42);
  const [ramUsage, setRamUsage] = useState(68);
  const [diskUsage, setDiskUsage] = useState(73);
  const [junkFiles, setJunkFiles] = useState(2.4);

  // 실시간 데이터 시뮬레이션
  useEffect(() => {
    const interval = setInterval(() => {
      setCpuUsage(prev => Math.max(15, Math.min(95, prev + (Math.random() - 0.5) * 10)));
      setRamUsage(prev => Math.max(30, Math.min(90, prev + (Math.random() - 0.5) * 8)));
      setDiskUsage(prev => Math.max(45, Math.min(95, prev + (Math.random() - 0.5) * 3)));
      setJunkFiles(prev => Math.max(0.1, prev + Math.random() * 0.1));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const getStatus = (value: number, type: 'cpu' | 'ram' | 'disk'): 'good' | 'warning' | 'critical' => {
    const thresholds = {
      cpu: { warning: 70, critical: 85 },
      ram: { warning: 75, critical: 90 },
      disk: { warning: 80, critical: 90 }
    };
    
    const threshold = thresholds[type];
    if (value >= threshold.critical) return 'critical';
    if (value >= threshold.warning) return 'warning';
    return 'good';
  };

  const getHealthScore = () => {
    const avgUsage = (cpuUsage + ramUsage + diskUsage) / 3;
    if (avgUsage < 60) return { score: 95, status: 'excellent' as const };
    if (avgUsage < 75) return { score: 75, status: 'good' as const };
    if (avgUsage < 85) return { score: 55, status: 'fair' as const };
    return { score: 30, status: 'poor' as const };
  };

  const performanceCards: PerformanceCard[] = [
    {
      id: 'cpu',
      friendlyName: '두뇌',
      techName: 'CPU (프로세서)',
      icon: Brain,
      emoji: '🧠',
      value: cpuUsage,
      max: 100,
      color: 'blue',
      status: getStatus(cpuUsage, 'cpu'),
      tooltip: 'CPU(프로세서): 노트북이 한 번에 계산하고 처리할 수 있는 힘. 숫자가 높을수록 작업 속도가 느려집니다.',
      recommendation: cpuUsage > 80 ? '무거운 프로그램을 잠시 끄거나 재시작해보세요' : undefined
    },
    {
      id: 'ram',
      friendlyName: '작업대',
      techName: 'RAM (메모리)',
      icon: BookOpen,
      emoji: '📚',
      value: ramUsage,
      max: 100,
      color: 'green',
      status: getStatus(ramUsage, 'ram'),
      tooltip: 'RAM(메모리): 여러 프로그램을 동시에 띄워 놓고 일할 수 있는 책상 크기. 작업대가 꽉 차면 노트북이 버벅거립니다.',
      recommendation: ramUsage > 85 ? '사용하지 않는 프로그램을 종료해보세요' : undefined
    },
    {
      id: 'disk',
      friendlyName: '파일 보관함',
      techName: '디스크 (저장공간)',
      icon: FolderOpen,
      emoji: '📁',
      value: diskUsage,
      max: 100,
      color: 'purple',
      status: getStatus(diskUsage, 'disk'),
      tooltip: '디스크(저장공간): 문서, 사진, 프로그램을 영구적으로 보관하는 창고. 용량이 가득 차면 새 파일 저장이 어렵습니다.',
      recommendation: diskUsage > 85 ? '불필요한 파일을 삭제하거나 다른 곳으로 옮겨보세요' : undefined
    }
  ];

  const healthScore = getHealthScore();

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'good':
      case 'excellent':
        return 'text-[#00ff88]';
      case 'warning':
      case 'fair':
        return 'text-[#00d4ff]';
      case 'critical':
      case 'poor':
        return 'text-[#ff2d5a]';
      default:
        return 'text-gray-400';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'good':
      case 'excellent':
        return <CheckCircle size={20} className="text-[#00ff88]" />;
      case 'warning':
      case 'fair':
        return <AlertTriangle size={20} className="text-[#00d4ff]" />;
      case 'critical':
      case 'poor':
        return <AlertTriangle size={20} className="text-[#ff2d5a]" />;
      default:
        return <HelpCircle size={20} className="text-gray-400" />;
    }
  };

  const getStatusMessage = (status: string) => {
    switch (status) {
      case 'excellent':
        return '완벽해요! 👍';
      case 'good':
        return '좋은 상태예요';
      case 'fair':
        return '보통이에요';
      case 'poor':
        return '관리가 필요해요';
      default:
        return '확인 중...';
    }
  };

  return (
    <TooltipProvider>
      <div className="space-y-8">
        {/* 헤더 */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <h1 className="text-4xl font-bold gradient-text mb-4">
            💻 우리 컴퓨터 건강 체크
          </h1>
          <p className="text-xl text-gray-300">
            복잡한 용어 없이, 쉽게 알아보는 컴퓨터 상태
          </p>
          <div className="mt-4 flex items-center justify-center space-x-2">
            <HelpCircle size={16} className="text-[#00d4ff]" />
            <span className="text-sm text-gray-400">
              각 항목에 마우스를 올려보세요. 자세한 설명이 나와요!
            </span>
          </div>
        </motion.div>

        {/* 종합 건강 점수 */}
        <GlassPanel delay={0.2} glow="green" className="p-8">
          <div className="text-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3, duration: 0.5 }}
            >
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="cursor-help">
                    <div className="flex items-center justify-center space-x-2 mb-4">
                      <Heart size={32} className="text-[#ff2d5a]" />
                      <h2 className="text-2xl font-bold text-white">노트북 건강 점수</h2>
                    </div>
                    <div className="text-6xl font-bold mb-2" style={{ color: healthScore.score > 70 ? '#00ff88' : healthScore.score > 50 ? '#00d4ff' : '#ff2d5a' }}>
                      {healthScore.score}점
                    </div>
                    <div className="flex items-center justify-center space-x-2">
                      {getStatusIcon(healthScore.status)}
                      <span className={`text-lg font-medium ${getStatusColor(healthScore.status)}`}>
                        {getStatusMessage(healthScore.status)}
                      </span>
                    </div>
                  </div>
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  <p className="font-medium mb-2">노트북 건강 점수 ❤️</p>
                  <p className="text-sm">
                    세 가지 요소를 종합해 판단한 노트북의 현재 건강 상태입니다.
                    점수가 높을수록 빠르고 안정적으로 작동해요.
                  </p>
                </TooltipContent>
              </Tooltip>
            </motion.div>
          </div>
        </GlassPanel>

        {/* 성능 카드들 */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {performanceCards.map((card, index) => {
            const Icon = card.icon;
            return (
              <motion.div
                key={card.id}
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 + index * 0.2, duration: 0.6 }}
              >
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="cursor-help">
                      <GlassPanel 
                        delay={0.5 + index * 0.1} 
                        glow={card.color} 
                        className="p-8 text-center hover:scale-105 transition-transform duration-500"
                      >
                        {/* 아이콘과 제목 */}
                        <div className="mb-6">
                          <div className="text-5xl mb-3">{card.emoji}</div>
                          <h3 className="text-2xl font-bold text-white mb-1">
                            {card.friendlyName}
                          </h3>
                          <p className="text-sm text-gray-400">
                            ({card.id === 'cpu' ? '처리 능력' : card.id === 'ram' ? '동시 작업 공간' : '남은 공간'})
                          </p>
                        </div>

                        {/* 원형 게이지 */}
                        <div className="mb-6">
                          <CircularGauge
                            value={card.value}
                            max={card.max}
                            label=""
                            color={card.color}
                            size={160}
                          />
                        </div>

                        {/* 상태 표시 */}
                        <div className="flex items-center justify-center space-x-2 mb-4">
                          {getStatusIcon(card.status)}
                          <span className={`font-medium ${getStatusColor(card.status)}`}>
                            {card.status === 'good' ? '좋아요!' : 
                             card.status === 'warning' ? '주의해요' : '조치 필요'}
                          </span>
                        </div>

                        {/* 추천 사항 */}
                        {card.recommendation && (
                          <div className="mt-4 p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
                            <p className="text-xs text-yellow-200">
                              💡 {card.recommendation}
                            </p>
                          </div>
                        )}
                      </GlassPanel>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent className="max-w-xs">
                    <p className="font-medium mb-2">{card.techName}</p>
                    <p className="text-sm">{card.tooltip}</p>
                  </TooltipContent>
                </Tooltip>
              </motion.div>
            );
          })}
        </div>

        {/* 쓰레기 파일 정리 섹션 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.6 }}
        >
          <GlassPanel glow="purple" className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="cursor-help flex items-center space-x-3">
                      <div className="text-3xl">🗑️</div>
                      <div>
                        <h3 className="text-xl font-bold text-white">쌓인 쓰레기 파일</h3>
                        <p className="text-sm text-gray-400">약 {junkFiles.toFixed(1)}GB</p>
                      </div>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent className="max-w-xs">
                    <p className="font-medium mb-2">쌓인 쓰레기 파일 🗑️</p>
                    <p className="text-sm">
                      노트북이 사용 후 남긴, 지워도 안전한 불필요한 파일들입니다.
                      정리하면 공간이 늘어나고 속도가 빨라져요.
                    </p>
                  </TooltipContent>
                </Tooltip>
                
                <Badge variant="outline" className="border-[#a855f7] text-[#a855f7]">
                  정리 추천
                </Badge>
              </div>

              <Button
                className="bg-gradient-to-r from-[#a855f7] to-[#00d4ff] hover:from-[#a855f7]/80 hover:to-[#00d4ff]/80 text-white font-bold"
              >
                <Trash2 size={16} />
                <span className="ml-2">지금 정리하기</span>
              </Button>
            </div>
          </GlassPanel>
        </motion.div>

        {/* 간단한 팁 섹션 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2, duration: 0.6 }}
        >
          <GlassPanel className="p-6">
            <h3 className="text-lg font-bold text-white mb-4 flex items-center">
              <TrendingUp size={20} className="text-[#00ff88] mr-2" />
              💡 오늘의 컴퓨터 관리 팁
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-300">
              <div className="flex items-start space-x-2">
                <span className="text-[#00d4ff]">•</span>
                <span>하루에 한 번 재시작하면 메모리가 깨끗해져요</span>
              </div>
              <div className="flex items-start space-x-2">
                <span className="text-[#00ff88]">•</span>
                <span>사용하지 않는 프로그램은 완전히 종료해주세요</span>
              </div>
              <div className="flex items-start space-x-2">
                <span className="text-[#a855f7]">•</span>
                <span>일주일에 한 번 쓰레기 파일을 정리해보세요</span>
              </div>
              <div className="flex items-start space-x-2">
                <span className="text-[#00d4ff]">•</span>
                <span>중요한 파일은 다른 곳에도 백업해두세요</span>
              </div>
            </div>
          </GlassPanel>
        </motion.div>
      </div>
    </TooltipProvider>
  );
}