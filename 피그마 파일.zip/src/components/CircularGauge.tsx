import { motion } from 'motion/react';
import { useEffect, useState } from 'react';

interface CircularGaugeProps {
  value: number;
  max: number;
  label: string;
  color: 'blue' | 'green' | 'purple';
  size?: number;
  emoji?: string;
  subtitle?: string;
}

export function CircularGauge({ value, max, label, color, size = 120, emoji, subtitle }: CircularGaugeProps) {
  const [animatedValue, setAnimatedValue] = useState(0);
  const percentage = (value / max) * 100;
  const radius = (size - 20) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDasharray = circumference;
  const strokeDashoffset = circumference - (animatedValue / 100) * circumference;

  const colors = {
    blue: '#00d4ff',
    green: '#00ff88',
    purple: '#a855f7'
  };

  const glowClass = {
    blue: 'neon-glow-blue',
    green: 'neon-glow-green',
    purple: 'neon-glow-purple'
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      setAnimatedValue(percentage);
    }, 100);
    return () => clearTimeout(timer);
  }, [percentage]);

  return (
    <div className="flex flex-col items-center space-y-3">
      <div className="relative" style={{ width: size, height: size }}>
        <svg
          width={size}
          height={size}
          className="transform -rotate-90"
        >
          {/* Background circle */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke="rgba(255, 255, 255, 0.08)"
            strokeWidth="12"
            fill="transparent"
          />
          
          {/* Progress circle */}
          <motion.circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke={colors[color]}
            strokeWidth="12"
            fill="transparent"
            strokeLinecap="round"
            strokeDasharray={strokeDasharray}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset }}
            transition={{ duration: 2, ease: "easeOut" }}
            className={`drop-shadow-lg ${glowClass[color]}`}
            style={{
              filter: `drop-shadow(0 0 12px ${colors[color]}60)`
            }}
          />
        </svg>
        
        {/* Center content */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.5, duration: 0.5 }}
            className="text-center"
          >
            {emoji && (
              <div className="text-3xl mb-1">{emoji}</div>
            )}
            <div 
              className="text-3xl font-bold"
              style={{ color: colors[color] }}
            >
              {Math.round(animatedValue)}%
            </div>
            {subtitle && (
              <div className="text-xs text-gray-400 mt-1">
                {subtitle}
              </div>
            )}
          </motion.div>
        </div>
      </div>
      
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7, duration: 0.5 }}
        className="text-center"
      >
        <div className="text-lg font-bold text-gray-200">{label}</div>
      </motion.div>
    </div>
  );
}