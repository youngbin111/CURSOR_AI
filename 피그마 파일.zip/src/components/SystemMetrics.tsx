import { motion } from 'motion/react';
import { CircularGauge } from './CircularGauge';
import { GlassPanel } from './GlassPanel';
import { 
  Cpu, 
  MemoryStick, 
  HardDrive, 
  Thermometer,
  Wifi,
  Battery,
  Activity
} from 'lucide-react';
import { useEffect, useState } from 'react';

interface MetricCardProps {
  icon: React.ComponentType<any>;
  label: string;
  value: string;
  unit: string;
  color: 'blue' | 'green' | 'purple';
  trend: 'up' | 'down' | 'stable';
  delay: number;
}

function MetricCard({ icon: Icon, label, value, unit, color, trend, delay }: MetricCardProps) {
  const colors = {
    blue: '#00d4ff',
    green: '#00ff88',
    purple: '#a855f7'
  };

  const trendColors = {
    up: '#ff2d5a',
    down: '#00ff88',
    stable: '#00d4ff'
  };

  return (
    <GlassPanel delay={delay} glow={color} className="p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center space-x-2">
          <Icon size={20} style={{ color: colors[color] }} />
          <span className="text-sm text-gray-300">{label}</span>
        </div>
        <div 
          className="w-2 h-2 rounded-full pulse-glow"
          style={{ backgroundColor: trendColors[trend] }}
        />
      </div>
      
      <div className="flex items-baseline space-x-1">
        <motion.span
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: delay + 0.3, duration: 0.5 }}
          className="text-2xl font-bold"
          style={{ color: colors[color] }}
        >
          {value}
        </motion.span>
        <span className="text-sm text-gray-400">{unit}</span>
      </div>
    </GlassPanel>
  );
}

export function SystemMetrics() {
  const [cpuUsage, setCpuUsage] = useState(45);
  const [ramUsage, setRamUsage] = useState(62);
  const [diskUsage, setDiskUsage] = useState(78);

  // 실시간 데이터 시뮬레이션
  useEffect(() => {
    const interval = setInterval(() => {
      setCpuUsage(prev => Math.max(0, Math.min(100, prev + (Math.random() - 0.5) * 10)));
      setRamUsage(prev => Math.max(0, Math.min(100, prev + (Math.random() - 0.5) * 8)));
      setDiskUsage(prev => Math.max(0, Math.min(100, prev + (Math.random() - 0.5) * 5)));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-6">
      {/* Main Gauges */}
      <GlassPanel delay={0.2} glow="blue" className="p-8">
        <motion.h3
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="text-2xl font-bold gradient-text mb-8 text-center"
        >
          💻 컨디션 체크 중... 
        </motion.h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 justify-items-center">
          <CircularGauge
            value={cpuUsage}
            max={100}
            label="🧠 두뇌 파워"
            color="blue"
            size={180}
            emoji="🧠"
            subtitle="생각하는 중..."
          />
          <CircularGauge
            value={ramUsage}
            max={100}
            label="⚡ 순간 기억력"
            color="green"
            size={180}
            emoji="⚡"
            subtitle="기억 보관함"
          />
          <CircularGauge
            value={diskUsage}
            max={100}
            label="📦 짐 창고"
            color="purple"
            size={180}
            emoji="📦"
            subtitle="짐 정리 필요?"
          />
        </div>
      </GlassPanel>

      {/* Detailed Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <MetricCard
          icon={Thermometer}
          label="🌡️ 체온"
          value="42"
          unit="°C"
          color="blue"
          trend="stable"
          delay={0.4}
        />
        <MetricCard
          icon={Activity}
          label="🌐 인터넷 속도"
          value="125"
          unit="Mbps"
          color="green"
          trend="up"
          delay={0.5}
        />
        <MetricCard
          icon={Battery}
          label="🔋 배터리"
          value="87"
          unit="%"
          color="purple"
          trend="down"
          delay={0.6}
        />
        <MetricCard
          icon={Wifi}
          label="📶 와이파이"
          value="강함"
          unit=""
          color="blue"
          trend="stable"
          delay={0.7}
        />
      </div>

      {/* Process List */}
      <GlassPanel delay={0.8} glow="green" className="p-6">
        <h4 className="text-lg font-bold text-[#00ff88] mb-4">👷‍♂️ 일하는 친구들</h4>
        <div className="space-y-3">
          {[
            { name: '🌐 Chrome (인터넷 서핑)', cpu: '12.5%', memory: '245 MB', color: '#00d4ff' },
            { name: '⚙️ System (시스템 관리자)', cpu: '8.2%', memory: '128 MB', color: '#00ff88' },
            { name: '💬 Discord (수다 담당)', cpu: '5.1%', memory: '156 MB', color: '#a855f7' },
            { name: '📁 Explorer (파일 탐험가)', cpu: '3.8%', memory: '89 MB', color: '#00d4ff' },
          ].map((process, index) => (
            <motion.div
              key={process.name}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.9 + index * 0.1, duration: 0.3 }}
              className="flex justify-between items-center p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
            >
              <span className="text-sm text-gray-300">{process.name}</span>
              <div className="flex space-x-4 text-xs">
                <span style={{ color: process.color }}>{process.cpu}</span>
                <span className="text-gray-400">{process.memory}</span>
              </div>
            </motion.div>
          ))}
        </div>
      </GlassPanel>
    </div>
  );
}