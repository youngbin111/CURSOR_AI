import { motion } from 'motion/react';
import { useState, useEffect } from 'react';
import { GlassPanel } from './GlassPanel';
import { CircularGauge } from './CircularGauge';
import { 
  Thermometer, 
  Fan, 
  Zap, 
  Wifi, 
  Battery,
  HardDrive,
  Trash2,
  AlertTriangle,
  CheckCircle,
  TrendingUp,
  TrendingDown,
  Activity,
  Clock,
  Shield
} from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

interface VitalWidget {
  icon: React.ComponentType<any>;
  label: string;
  value: string;
  unit: string;
  color: 'blue' | 'green' | 'purple' | 'orange' | 'red';
  trend?: 'up' | 'down' | 'stable';
  status?: 'good' | 'warning' | 'critical';
}

export function PerformanceDashboard() {
  const [cpuUsage, setCpuUsage] = useState(45);
  const [ramUsage, setRamUsage] = useState(62);
  const [diskUsage, setDiskUsage] = useState(78);
  const [cpuTemp, setCpuTemp] = useState(42);
  const [fanSpeed, setFanSpeed] = useState(1200);
  const [powerConsumption, setPowerConsumption] = useState(65);
  const [junkFilesSize, setJunkFilesSize] = useState(2.4);
  const [isOptimizing, setIsOptimizing] = useState(false);

  // 실시간 데이터 시뮬레이션
  useEffect(() => {
    const interval = setInterval(() => {
      setCpuUsage(prev => Math.max(15, Math.min(95, prev + (Math.random() - 0.5) * 12)));
      setRamUsage(prev => Math.max(30, Math.min(90, prev + (Math.random() - 0.5) * 8)));
      setDiskUsage(prev => Math.max(50, Math.min(95, prev + (Math.random() - 0.5) * 3)));
      setCpuTemp(prev => Math.max(30, Math.min(75, prev + (Math.random() - 0.5) * 4)));
      setFanSpeed(prev => Math.max(800, Math.min(2000, prev + (Math.random() - 0.5) * 200)));
      setPowerConsumption(prev => Math.max(35, Math.min(85, prev + (Math.random() - 0.5) * 6)));
      setJunkFilesSize(prev => Math.max(0.1, prev + Math.random() * 0.05));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const vitals: VitalWidget[] = [
    {
      icon: Thermometer,
      label: 'CPU 온도',
      value: cpuTemp.toFixed(0),
      unit: '°C',
      color: cpuTemp > 65 ? 'red' : cpuTemp > 55 ? 'orange' : 'blue',
      trend: cpuTemp > 60 ? 'up' : cpuTemp < 45 ? 'down' : 'stable',
      status: cpuTemp > 70 ? 'critical' : cpuTemp > 60 ? 'warning' : 'good'
    },
    {
      icon: Fan,
      label: '팬 속도',
      value: fanSpeed.toFixed(0),
      unit: 'RPM',
      color: 'green',
      trend: fanSpeed > 1500 ? 'up' : 'stable',
      status: 'good'
    },
    {
      icon: Zap,
      label: '전력 소비',
      value: powerConsumption.toFixed(0),
      unit: 'W',
      color: 'purple',
      trend: powerConsumption > 70 ? 'up' : 'stable',
      status: powerConsumption > 75 ? 'warning' : 'good'
    },
    {
      icon: Wifi,
      label: '네트워크',
      value: '125',
      unit: 'Mbps',
      color: 'blue',
      trend: 'stable',
      status: 'good'
    },
    {
      icon: Battery,
      label: '배터리',
      value: '87',
      unit: '%',
      color: 'green',
      trend: 'down',
      status: 'good'
    },
    {
      icon: Shield,
      label: '보안 상태',
      value: '활성',
      unit: '',
      color: 'green',
      trend: 'stable',
      status: 'good'
    },
    {
      icon: Clock,
      label: '업타임',
      value: '4h 32m',
      unit: '',
      color: 'blue',
      trend: 'up',
      status: 'good'
    },
    {
      icon: Activity,
      label: '네트워크 사용률',
      value: '12',
      unit: '%',
      color: 'purple',
      trend: 'stable',
      status: 'good'
    }
  ];

  const handleCleanup = () => {
    setIsOptimizing(true);
    setTimeout(() => {
      setJunkFilesSize(0.2);
      setIsOptimizing(false);
    }, 3000);
  };

  const getColorByUsage = (usage: number): 'blue' | 'green' | 'purple' => {
    if (usage < 50) return 'green';
    if (usage < 75) return 'blue';
    return 'purple';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'good': return 'text-[#00ff88]';
      case 'warning': return 'text-[#00d4ff]';
      case 'critical': return 'text-[#ff2d5a]';
      default: return 'text-gray-400';
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp size={12} className="text-[#ff2d5a]" />;
      case 'down': return <TrendingDown size={12} className="text-[#00ff88]" />;
      case 'stable': return <div className="w-3 h-0.5 bg-gray-400 rounded"></div>;
      default: return null;
    }
  };

  const getVitalWidgetColor = (color: string) => {
    const colors = {
      blue: 'border-[#00d4ff]/30 bg-[#00d4ff]/5',
      green: 'border-[#00ff88]/30 bg-[#00ff88]/5',
      purple: 'border-[#a855f7]/30 bg-[#a855f7]/5',
      orange: 'border-[#f59e0b]/30 bg-[#f59e0b]/5',
      red: 'border-[#ff2d5a]/30 bg-[#ff2d5a]/5'
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  return (
    <div className="grid grid-cols-12 gap-6 h-full">
      {/* 메인 성능 지표 영역 */}
      <div className="col-span-8 space-y-6">
        {/* 헤더 */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-3xl font-bold gradient-text mb-2">성능 모니터링</h1>
          <p className="text-gray-400">실시간 시스템 상태 및 리소스 사용량</p>
        </motion.div>

        {/* 원형 게이지 패널 */}
        <GlassPanel delay={0.2} glow="blue" className="p-8">
          <div className="grid grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3, duration: 0.6 }}
              className="text-center"
            >
              <CircularGauge
                value={cpuUsage}
                max={100}
                label="CPU 사용률"
                color={getColorByUsage(cpuUsage)}
                size={180}
              />
              <div className="mt-4">
                <div className="flex items-center justify-center space-x-2">
                  {cpuUsage > 80 ? 
                    <AlertTriangle size={16} className="text-[#ff2d5a]" /> :
                    <CheckCircle size={16} className="text-[#00ff88]" />
                  }
                  <span className={`text-sm font-medium ${cpuUsage > 80 ? 'text-[#ff2d5a]' : 'text-[#00ff88]'}`}>
                    {cpuUsage > 80 ? '높음' : cpuUsage > 50 ? '보통' : '낮음'}
                  </span>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.4, duration: 0.6 }}
              className="text-center"
            >
              <CircularGauge
                value={ramUsage}
                max={100}
                label="RAM 사용률"
                color={getColorByUsage(ramUsage)}
                size={180}
              />
              <div className="mt-4">
                <div className="flex items-center justify-center space-x-2">
                  {ramUsage > 85 ? 
                    <AlertTriangle size={16} className="text-[#ff2d5a]" /> :
                    <CheckCircle size={16} className="text-[#00ff88]" />
                  }
                  <span className={`text-sm font-medium ${ramUsage > 85 ? 'text-[#ff2d5a]' : 'text-[#00ff88]'}`}>
                    {ramUsage > 85 ? '높음' : ramUsage > 60 ? '보통' : '낮음'}
                  </span>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5, duration: 0.6 }}
              className="text-center"
            >
              <CircularGauge
                value={diskUsage}
                max={100}
                label="디스크 사용률"
                color={getColorByUsage(diskUsage)}
                size={180}
              />
              <div className="mt-4">
                <div className="flex items-center justify-center space-x-2">
                  {diskUsage > 90 ? 
                    <AlertTriangle size={16} className="text-[#ff2d5a]" /> :
                    <CheckCircle size={16} className="text-[#00ff88]" />
                  }
                  <span className={`text-sm font-medium ${diskUsage > 90 ? 'text-[#ff2d5a]' : 'text-[#00ff88]'}`}>
                    {diskUsage > 90 ? '높음' : diskUsage > 75 ? '보통' : '낮음'}
                  </span>
                </div>
              </div>
            </motion.div>
          </div>
        </GlassPanel>

        {/* 디스크 정리 섹션 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.6 }}
        >
          <GlassPanel glow="purple" className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="p-3 rounded-lg bg-[#a855f7]/20 border border-[#a855f7]/30">
                  <Trash2 size={24} className="text-[#a855f7]" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">불필요한 파일 정리</h3>
                  <p className="text-gray-400">
                    쌓인 임시 파일: <span className="text-[#a855f7] font-medium">{junkFilesSize.toFixed(2)} GB</span>
                  </p>
                </div>
                <Badge 
                  variant="outline" 
                  className="border-[#a855f7] text-[#a855f7]"
                >
                  {junkFilesSize > 2 ? '정리 권장' : '깨끗함'}
                </Badge>
              </div>
              
              <Button
                onClick={handleCleanup}
                disabled={isOptimizing}
                className="bg-gradient-to-r from-[#a855f7] to-[#00d4ff] hover:from-[#a855f7]/80 hover:to-[#00d4ff]/80 text-white font-bold px-8 py-3"
              >
                {isOptimizing ? (
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    <span>정리 중...</span>
                  </div>
                ) : (
                  <div className="flex items-center space-x-2">
                    <Trash2 size={16} />
                    <span>지금 정리하기</span>
                  </div>
                )}
              </Button>
            </div>
          </GlassPanel>
        </motion.div>
      </div>

      {/* 바이탈 사인 사이드바 */}
      <div className="col-span-4 space-y-4">
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3, duration: 0.6 }}
        >
          <h2 className="text-xl font-bold text-white mb-4 flex items-center">
            <Activity size={20} className="text-[#00ff88] mr-2" />
            시스템 바이탈 사인
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 gap-3">
          {vitals.map((vital, index) => {
            const Icon = vital.icon;
            return (
              <motion.div
                key={vital.label}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 + index * 0.05, duration: 0.4 }}
              >
                <div className={`p-4 rounded-lg border backdrop-blur-sm transition-all duration-300 hover:scale-105 ${getVitalWidgetColor(vital.color)}`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-lg bg-${vital.color === 'blue' ? '[#00d4ff]' : vital.color === 'green' ? '[#00ff88]' : vital.color === 'purple' ? '[#a855f7]' : vital.color === 'orange' ? '[#f59e0b]' : '[#ff2d5a]'}/20`}>
                        <Icon size={16} className={`text-${vital.color === 'blue' ? '[#00d4ff]' : vital.color === 'green' ? '[#00ff88]' : vital.color === 'purple' ? '[#a855f7]' : vital.color === 'orange' ? '[#f59e0b]' : '[#ff2d5a]'}`} />
                      </div>
                      <div>
                        <p className="text-xs text-gray-400">{vital.label}</p>
                        <div className="flex items-center space-x-1">
                          <span className="text-sm font-bold text-white">
                            {vital.value} {vital.unit}
                          </span>
                          {vital.trend && getTrendIcon(vital.trend)}
                        </div>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      {vital.status && (
                        <div className={`text-xs font-medium ${getStatusColor(vital.status)}`}>
                          {vital.status === 'good' ? '정상' : vital.status === 'warning' ? '주의' : '위험'}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}