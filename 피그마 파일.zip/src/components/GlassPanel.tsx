import { motion } from 'motion/react';
import { ReactNode } from 'react';

interface GlassPanelProps {
  children: ReactNode;
  className?: string;
  glow?: 'blue' | 'green' | 'purple' | 'none';
  delay?: number;
}

export function GlassPanel({ children, className = '', glow = 'none', delay = 0 }: GlassPanelProps) {
  const glowClasses = {
    blue: 'neon-glow-blue',
    green: 'neon-glow-green',
    purple: 'neon-glow-purple',
    none: ''
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.6, ease: "easeOut" }}
      className={`glass-panel ${glowClasses[glow]} ${className}`}
    >
      {children}
    </motion.div>
  );
}