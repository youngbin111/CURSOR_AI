import { motion } from 'motion/react';
import { useState, useEffect } from 'react';
import { GlassPanel } from './GlassPanel';
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { 
  Monitor, 
  Cpu, 
  HardDrive, 
  Activity, 
  Server,
  Database,
  Network,
  TrendingUp,
  Clock,
  Users
} from 'lucide-react';
import { Badge } from './ui/badge';

interface TimeSeriesData {
  time: string;
  cpu: number;
  memory: number;
  disk: number;
  requests: number;
  network: number;
}

interface CoreUsageData {
  core: string;
  usage: number;
  temperature: number;
}

interface DiskData {
  name: string;
  used: number;
  total: number;
  percentage: number;
  color: string;
}

export function GrafanaStyleDashboard() {
  const [timeSeriesData, setTimeSeriesData] = useState<TimeSeriesData[]>([]);
  const [coreUsageData, setCoreUsageData] = useState<CoreUsageData[]>([]);
  const [diskData, setDiskData] = useState<DiskData[]>([]);
  const [currentTime, setCurrentTime] = useState(new Date());

  // 초기 데이터 생성
  useEffect(() => {
    const generateInitialData = () => {
      const data: TimeSeriesData[] = [];
      const now = new Date();
      
      for (let i = 59; i >= 0; i--) {
        const time = new Date(now.getTime() - i * 1000);
        data.push({
          time: time.toLocaleTimeString('ko-KR', { 
            hour: '2-digit', 
            minute: '2-digit', 
            second: '2-digit' 
          }),
          cpu: Math.random() * 80 + 10,
          memory: Math.random() * 70 + 20,
          disk: Math.random() * 30 + 40,
          requests: Math.random() * 500 + 100,
          network: Math.random() * 100 + 50
        });
      }
      setTimeSeriesData(data);
    };

    const generateCoreData = () => {
      const cores: CoreUsageData[] = [];
      for (let i = 0; i < 8; i++) {
        cores.push({
          core: `Core ${i}`,
          usage: Math.random() * 90 + 5,
          temperature: Math.random() * 30 + 40
        });
      }
      setCoreUsageData(cores);
    };

    const generateDiskData = () => {
      setDiskData([
        { name: 'C: System', used: 156, total: 250, percentage: 62, color: '#00d4ff' },
        { name: 'D: Data', used: 89, total: 500, percentage: 18, color: '#00ff88' },
        { name: 'E: Backup', used: 340, total: 1000, percentage: 34, color: '#a855f7' }
      ]);
    };

    generateInitialData();
    generateCoreData();
    generateDiskData();
  }, []);

  // 실시간 데이터 업데이트
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(new Date());
      
      setTimeSeriesData(prev => {
        const newData = [...prev.slice(1)];
        const now = new Date();
        newData.push({
          time: now.toLocaleTimeString('ko-KR', { 
            hour: '2-digit', 
            minute: '2-digit', 
            second: '2-digit' 
          }),
          cpu: Math.random() * 80 + 10,
          memory: Math.random() * 70 + 20,
          disk: Math.random() * 30 + 40,
          requests: Math.random() * 500 + 100,
          network: Math.random() * 100 + 50
        });
        return newData;
      });

      setCoreUsageData(prev => 
        prev.map(core => ({
          ...core,
          usage: Math.max(5, Math.min(95, core.usage + (Math.random() - 0.5) * 20)),
          temperature: Math.max(35, Math.min(75, core.temperature + (Math.random() - 0.5) * 5))
        }))
      );
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-[#0f0f14]/95 backdrop-blur-sm border border-gray-600 rounded-lg p-3 shadow-xl">
          <p className="text-gray-300 text-sm mb-1">{`시간: ${label}`}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} style={{ color: entry.color }} className="text-sm font-medium">
              {`${entry.name}: ${entry.value.toFixed(1)}${entry.name.includes('요청') ? '' : '%'}`}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  const formatTickTime = (time: string) => {
    const parts = time.split(':');
    return `${parts[1]}:${parts[2]}`;
  };

  return (
    <div className="space-y-6">
      {/* 헤더 */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-3xl font-bold gradient-text mb-2">시스템 모니터링</h1>
          <p className="text-gray-400">실시간 시스템 메트릭 대시보드</p>
        </div>
        <div className="flex items-center space-x-4">
          <Badge variant="outline" className="border-[#00ff88] text-[#00ff88]">
            <div className="w-2 h-2 bg-[#00ff88] rounded-full mr-2 animate-pulse"></div>
            실시간
          </Badge>
          <div className="text-sm text-gray-400">
            <Clock size={16} className="inline mr-1" />
            {currentTime.toLocaleTimeString('ko-KR')}
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-12 gap-6">
        {/* 상단: CPU & 메모리 트렌드 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.6 }}
          className="col-span-8"
        >
          <GlassPanel glow="blue" className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-white flex items-center">
                <Activity size={20} className="text-[#00d4ff] mr-2" />
                CPU & 메모리 사용률 트렌드
              </h2>
              <div className="flex items-center space-x-4 text-sm">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-[#00d4ff] rounded-full mr-2"></div>
                  <span className="text-gray-300">CPU</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-[#00ff88] rounded-full mr-2"></div>
                  <span className="text-gray-300">메모리</span>
                </div>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={timeSeriesData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis 
                  dataKey="time" 
                  stroke="#94a3b8"
                  fontSize={12}
                  tickFormatter={formatTickTime}
                />
                <YAxis stroke="#94a3b8" fontSize={12} domain={[0, 100]} />
                <Tooltip content={<CustomTooltip />} />
                <Line 
                  type="monotone" 
                  dataKey="cpu" 
                  stroke="#00d4ff" 
                  strokeWidth={2}
                  dot={false}
                  name="CPU"
                />
                <Line 
                  type="monotone" 
                  dataKey="memory" 
                  stroke="#00ff88" 
                  strokeWidth={2}
                  dot={false}
                  name="메모리"
                />
              </LineChart>
            </ResponsiveContainer>
          </GlassPanel>
        </motion.div>

        {/* 디스크 사용량 게이지 */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="col-span-4 space-y-4"
        >
          <GlassPanel glow="purple" className="p-6">
            <h3 className="text-lg font-bold text-white mb-4 flex items-center">
              <HardDrive size={18} className="text-[#a855f7] mr-2" />
              디스크 사용량
            </h3>
            <div className="space-y-4">
              {diskData.map((disk, index) => (
                <div key={disk.name} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-300">{disk.name}</span>
                    <span className="text-xs text-gray-400">
                      {disk.used}GB / {disk.total}GB
                    </span>
                  </div>
                  <div className="w-full bg-gray-700/50 rounded-full h-2">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${disk.percentage}%` }}
                      transition={{ delay: 0.5 + index * 0.1, duration: 1 }}
                      className="h-2 rounded-full"
                      style={{ backgroundColor: disk.color }}
                    />
                  </div>
                  <div className="text-xs text-gray-400 text-right">
                    {disk.percentage}%
                  </div>
                </div>
              ))}
            </div>
          </GlassPanel>

          {/* 시스템 상태 요약 */}
          <GlassPanel className="p-4">
            <h4 className="text-sm font-bold text-white mb-3 flex items-center">
              <Monitor size={16} className="text-[#00d4ff] mr-2" />
              시스템 상태
            </h4>
            <div className="space-y-3 text-xs">
              <div className="flex justify-between">
                <span className="text-gray-400">가동 시간</span>
                <span className="text-[#00ff88]">12:34:56</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">프로세스</span>
                <span className="text-white">247</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">네트워크 I/O</span>
                <span className="text-[#00d4ff]">↑ 1.2 MB/s ↓ 3.4 MB/s</span>
              </div>
            </div>
          </GlassPanel>
        </motion.div>

        {/* 중단: 서버 요청량 누적 그래프 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
          className="col-span-8"
        >
          <GlassPanel glow="green" className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-white flex items-center">
                <Server size={20} className="text-[#00ff88] mr-2" />
                서버 요청량 & 네트워크 트래픽
              </h2>
              <div className="flex items-center space-x-4 text-sm">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-[#a855f7] rounded-full mr-2"></div>
                  <span className="text-gray-300">요청/초</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-[#f59e0b] rounded-full mr-2"></div>
                  <span className="text-gray-300">네트워크</span>
                </div>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={250}>
              <AreaChart data={timeSeriesData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis 
                  dataKey="time" 
                  stroke="#94a3b8"
                  fontSize={12}
                  tickFormatter={formatTickTime}
                />
                <YAxis stroke="#94a3b8" fontSize={12} />
                <Tooltip content={<CustomTooltip />} />
                <Area
                  type="monotone"
                  dataKey="requests"
                  stackId="1"
                  stroke="#a855f7"
                  fill="rgba(168, 85, 247, 0.3)"
                  name="요청"
                />
                <Area
                  type="monotone"
                  dataKey="network"
                  stackId="1"
                  stroke="#f59e0b"
                  fill="rgba(245, 158, 11, 0.3)"
                  name="네트워크"
                />
              </AreaChart>
            </ResponsiveContainer>
          </GlassPanel>
        </motion.div>

        {/* 실시간 메트릭 카드들 */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5, duration: 0.6 }}
          className="col-span-4 space-y-4"
        >
          <GlassPanel className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="p-2 rounded-lg bg-[#00d4ff]/20">
                  <TrendingUp size={16} className="text-[#00d4ff]" />
                </div>
                <div className="ml-3">
                  <p className="text-xs text-gray-400">평균 응답시간</p>
                  <p className="text-lg font-bold text-white">124ms</p>
                </div>
              </div>
              <Badge variant="outline" className="border-[#00ff88] text-[#00ff88] text-xs">
                양호
              </Badge>
            </div>
          </GlassPanel>

          <GlassPanel className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="p-2 rounded-lg bg-[#00ff88]/20">
                  <Users size={16} className="text-[#00ff88]" />
                </div>
                <div className="ml-3">
                  <p className="text-xs text-gray-400">활성 사용자</p>
                  <p className="text-lg font-bold text-white">1,247</p>
                </div>
              </div>
              <div className="text-xs text-[#00ff88]">
                +12%
              </div>
            </div>
          </GlassPanel>

          <GlassPanel className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="p-2 rounded-lg bg-[#a855f7]/20">
                  <Database size={16} className="text-[#a855f7]" />
                </div>
                <div className="ml-3">
                  <p className="text-xs text-gray-400">DB 쿼리/초</p>
                  <p className="text-lg font-bold text-white">89</p>
                </div>
              </div>
              <div className="text-xs text-[#ff2d5a]">
                -3%
              </div>
            </div>
          </GlassPanel>
        </motion.div>

        {/* 하단: CPU 코어별 사용률 막대 그래프 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.6 }}
          className="col-span-12"
        >
          <GlassPanel glow="purple" className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-white flex items-center">
                <Cpu size={20} className="text-[#a855f7] mr-2" />
                CPU 코어별 사용률 & 온도
              </h2>
              <div className="flex items-center space-x-4 text-sm">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-[#00d4ff] rounded-full mr-2"></div>
                  <span className="text-gray-300">사용률 (%)</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-1 bg-[#ff2d5a] rounded-full mr-2"></div>
                  <span className="text-gray-300">온도 (°C)</span>
                </div>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={coreUsageData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis dataKey="core" stroke="#94a3b8" fontSize={12} />
                <YAxis stroke="#94a3b8" fontSize={12} domain={[0, 100]} />
                <Tooltip 
                  content={({ active, payload, label }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="bg-[#0f0f14]/95 backdrop-blur-sm border border-gray-600 rounded-lg p-3 shadow-xl">
                          <p className="text-gray-300 text-sm mb-1">{label}</p>
                          <p className="text-[#00d4ff] text-sm font-medium">
                            사용률: {payload[0]?.value?.toFixed(1)}%
                          </p>
                          <p className="text-[#ff2d5a] text-sm font-medium">
                            온도: {payload[0]?.payload?.temperature?.toFixed(1)}°C
                          </p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar 
                  dataKey="usage" 
                  fill="url(#barGradient)" 
                  radius={[2, 2, 0, 0]}
                />
                <defs>
                  <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#00d4ff" stopOpacity={0.8} />
                    <stop offset="100%" stopColor="#a855f7" stopOpacity={0.8} />
                  </linearGradient>
                </defs>
              </BarChart>
            </ResponsiveContainer>
          </GlassPanel>
        </motion.div>
      </div>
    </div>
  );
}