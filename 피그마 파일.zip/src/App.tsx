import { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { NavigationBar } from './components/NavigationBar';
import { SystemMetrics } from './components/SystemMetrics';
import { DiskCleanup } from './components/DiskCleanup';
import { SystemOptimization } from './components/SystemOptimization';
import { BeginnerFriendlyDashboard } from './components/BeginnerFriendlyDashboard';
import { PerformanceDashboard } from './components/PerformanceDashboard';
import { GrafanaStyleDashboard } from './components/GrafanaStyleDashboard';

export default function App() {
  const [activeTab, setActiveTab] = useState('grafana');

  useEffect(() => {
    document.body.classList.add('dark');
    document.body.className = 'dark bg-[#0a0a0b] cyber-grid min-h-screen';
  }, []);

  const renderContent = () => {
    switch (activeTab) {
      case 'grafana':
        return <GrafanaStyleDashboard />;
      case 'performance':
        return <PerformanceDashboard />;
      case 'beginner':
        return <BeginnerFriendlyDashboard />;
      case 'dashboard':
        return <SystemMetrics />;
      case 'storage':
        return <DiskCleanup />;
      case 'optimization':
        return <SystemOptimization />;
      default:
        return (
          <div className="glass-panel p-8 text-center">
            <h2 className="text-2xl font-bold gradient-text mb-4">
              {getTabTitle(activeTab)}
            </h2>
            <p className="text-gray-400">
              이 섹션은 현재 개발 중입니다.
            </p>
          </div>
        );
    }
  };

  const getTabTitle = (tabId: string) => {
    const titles: Record<string, string> = {
      grafana: '시스템 모니터링',
      performance: '성능 대시보드',
      beginner: '쉬운 건강체크',
      dashboard: '시스템 진단',
      storage: '디스크 정리',
      optimization: '시스템 최적화',
      settings: '설정'
    };
    return titles[tabId] || '알 수 없음';
  };

  return (
    <div className="min-h-screen bg-[#0a0a0b] cyber-grid">
      <div className="flex h-screen">
        {/* Sidebar Navigation */}
        <NavigationBar 
          activeTab={activeTab} 
          onTabChange={setActiveTab} 
        />
        
        {/* Main Content */}
        <div className="flex-1 flex flex-col overflow-hidden">
          <Header />
          
          <main className="flex-1 overflow-auto p-6">
            {renderContent()}
          </main>
        </div>
      </div>
    </div>
  );
}