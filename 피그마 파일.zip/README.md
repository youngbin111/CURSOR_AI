
  # PC Optimization Dashboard Design

  This is a code bundle for PC Optimization Dashboard Design. The original project is available at https://www.figma.com/design/I6oVRP8yGG4D6Zev1emYHk/PC-Optimization-Dashboard-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  